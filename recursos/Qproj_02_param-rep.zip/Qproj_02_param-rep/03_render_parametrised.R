#- render parametrised reports
fs::dir_create("informes")

#- elegimos países para los q queremos hacer el informe -----
paises <- c("ESP", "SVN")

nn_paises <- length(paises)  #- nº de países


for (ii in 1:nn_paises){
  my_pais = paises[ii]
  my_titulo_del_informe <- paste0("informe-", my_pais, ".html")
  quarto::quarto_render(
    input = "02_informe_parametrizado_infla.qmd",
    output_file = my_titulo_del_informe,
    execute_params = list(country = my_pais)
  )
  full_path_source <- here::here(my_titulo_del_informe)
  full_path_destination <- here::here("informes", my_titulo_del_informe)
  fs::file_move(full_path_source, full_path_destination)
}
